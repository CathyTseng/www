﻿let userinfo;
let localStream;
let myRtcConstraint = { video: true, audio: true };
let $VM2 = window.opener.get$VM();
let $OPENWINDOW = window.opener.get$OPENWINDOW();
let collapse = false;
let durationStart = Date.now();

function processMessageFromParent(data) {

    let CameraRemote = document.getElementById("CameraRemote");
    let CameraLocal = document.getElementById("CameraLocal");
    let avatar2 = document.getElementById("avatar2");
    var obj = JSON.parse(data);

    if (obj.mqttCommand) {
        let mqttCommand = obj.mqttCommand;
        switch (mqttCommand) {
            case "OpenVideo":
                document.getElementById("CameraRemote").style.display = "block";
                document.getElementById("avatar2").style.display = "none";
                break;
            case "CloseVideo":
                document.getElementById("CameraRemote").style.display = "none";
                //if ($VM2.$children[0].eTeam.rtcService.remoteStream.getVideoTracks()[0].enabled == 0) {
                if (document.getElementById("VideoRemote").style.display == "none") {
                    document.getElementById("avatar2").style.display = "";
                }
                else {
                    document.getElementById("avatar2").style.display = "none";
                }
                break;
            case "OpenShare":
                let VideoRemote = document.getElementById("VideoRemote")
                VideoRemote.style.display = "block";
                VideoRemote.style.top = "0px";
                VideoRemote.style.left = "0px";

                //let height = document.body.clientHeight;
                //let width = document.body.clientWidth;   

                document.getElementById("CameraRemote").style.top = "5px";
                document.getElementById("CameraRemote").style.left = (screen.width - 230) + "px";

                document.getElementById("CameraRemote").style.zIndex = "99";
                document.getElementById("CameraRemote").style.width = "200px";

                document.getElementById("CameraLocal").style.width = "200px";
                document.getElementById("CameraLocal").style.top = "200px";
                document.getElementById("CameraLocal").style.left = (screen.width - 230) + "px";
                document.getElementById("CameraLocal").style.zIndex = "99";
                document.getElementById("avatar2").style.display = "none";

                break;
            case "CloseShare":
                document.getElementById("VideoRemote").style.display = "none";

                document.getElementById("CameraRemote").style.width = "600px";
                document.getElementById("CameraRemote").style.top = "85px";
                document.getElementById("CameraRemote").style.left = (screen.width - 600) / 2 + "px";
                document.getElementById("CameraRemote").style.zIndex = "99";
                if ($VM2.$children[0].eTeam.rtcService.localStream_webcam.getVideoTracks()[0].enabled == 0) {
                    document.getElementById("avatar2").style.display = "";
                }
                break;
            case "Cancel":
            case "Hangup":
            case "Decline":
                webrtcObj.closeMyself("");
                break;
            default:
                console.log(`[processMessageFromParent]沒有預期的種類:[mqttCommand:${mqttCommand}]`);
                break;
        }
    }
}








class webrtc {

    init() {
        //alert("init");
        const self = this;

        //mouse hove 至 dockmenu 則顯示dockmenu
        var dockmenu = document.getElementById('dockmenu');
        dockmenu.addEventListener('mouseover', function () {
            if (collapse == true) {
                collapse = false;
                var dockmenu = document.getElementById('dockmenu');
                dockmenu.classList.remove("hiddenHeight");
                dockmenu.classList.add("showHeight");
                dockmenu.style.height = "80px";
                var ul_dockmenu = document.getElementById("ul_dockmenu");
                ul_dockmenu.classList.remove("hiddenHeight");
                ul_dockmenu.classList.add("showHeight");
                ul_dockmenu.style.removeProperty("height");
                var itag = document.querySelector("#dockmenu").querySelectorAll("i");
                for (var i = 0; i < itag.length; i++) {
                    itag[i].classList.remove("hiddenHeight");

                    itag[i].classList.add("showHeight");
                    itag[i].style.removeProperty("height");
                    //itag[i].style.height = "74px";
                }
            }
        }, false);

        //收合
        var li_hidden = document.getElementById('li_hidden');
        li_hidden.addEventListener('click', function () {

            //var dockmenu = document.getElementById('dockmenu');
            //dockmenu.classList.remove("showHeight");
            //dockmenu.classList.add("hiddenHeight");
            //dockmenu.style.height = "5px";    
            //var ul_dockmenu = document.getElementById("ul_dockmenu");
            //ul_dockmenu.style.display = "none";

            var dockmenu = document.getElementById('dockmenu');
            dockmenu.classList.remove("showHeight");
            dockmenu.classList.add("hiddenHeight");
            dockmenu.style.height = "5px";
            //dockmenu.style.display = "none";
            var ul_dockmenu = document.getElementById("ul_dockmenu");
            //ul_dockmenu.style.display = "none";
            ul_dockmenu.classList.add("hiddenHeight");
            ul_dockmenu.style.height = "5px";

            var itag = document.querySelector("#dockmenu").querySelectorAll("i");
            for (var i = 0; i < itag.length; i++) {
                itag[i].classList.remove("showHeight");
                itag[i].classList.add("hiddenHeight");
                itag[i].style.height = "5px";
            }

            setTimeout(function () { collapse = true; }, 600);
        }, false);



        //靜音
        var li_mute = document.getElementById("li_mute");
        li_mute.addEventListener('click', function () {


            if ($VM2.$children[0].eTeam.rtcService.localStream_webcam.getAudioTracks()[0].enabled == 0) {
                $VM2.$children[0].eTeam.rtcService.localStream_webcam.getAudioTracks()[0].enabled = 1;
                //$VM2.$children[0].eTeam.rtcService.OpenVideo();
            }
            else {
                $VM2.$children[0].eTeam.rtcService.localStream_webcam.getAudioTracks()[0].enabled = 0;
                //$VM2.$children[0].eTeam.rtcService.CloseVideo();
            }

            var itag = document.querySelector("#li_mute").querySelector("i");
            if (itag.classList.contains("using")) {
                itag.classList.remove("using");
                itag.classList.add("normal");
            }
            else {
                itag.classList.add("using");
                itag.classList.remove("normal");
            }
        }, false);

        //分享視訊
        var li_video = document.getElementById("li_video");
        li_video.addEventListener('click', function () {
            //let tracks = $VM2.$children[0].eTeam.rtcService.localStream_webcam.getTracks();    
            //tracks.forEach(function (track) {
            //    track.stop();
            //});
            if ($VM2.$children[0].eTeam.rtcService.localStream_webcam.getVideoTracks()[0].enabled == 0) {
                $VM2.$children[0].eTeam.rtcService.localStream_webcam.getVideoTracks()[0].enabled = 1;
                $VM2.$children[0].eTeam.rtcService.OpenVideo();
            }
            else {
                $VM2.$children[0].eTeam.rtcService.localStream_webcam.getVideoTracks()[0].enabled = 0;
                $VM2.$children[0].eTeam.rtcService.CloseVideo();
            }

            var itag = document.querySelector("#li_video").querySelector("i");
            if (itag.classList.contains("using")) {
                itag.classList.remove("using");
                itag.classList.add("normal");
                document.getElementById("CameraLocal").style.display = "none";
            }
            else {
                itag.classList.add("using");
                itag.classList.remove("normal");
                document.getElementById("CameraLocal").style.display = "";
            }
        }, false);

        //分享桌面
        var li_share = document.getElementById("li_share");
        li_share.addEventListener('click', function () {

            if ($VM2.$children[0].eTeam.rtcService.localStream.getVideoTracks()[0].enabled == 0) {
                $VM2.$children[0].eTeam.rtcService.localStream.getVideoTracks()[0].enabled = 1;
                $VM2.$children[0].eTeam.rtcService.OpenShare();
            }
            else {
                $VM2.$children[0].eTeam.rtcService.localStream.getVideoTracks()[0].enabled = 0;
                $VM2.$children[0].eTeam.rtcService.CloseShare();
            }

            var itag = document.querySelector("#li_share").querySelector("i");
            if (itag.classList.contains("using")) {
                itag.classList.remove("using");
                itag.classList.add("normal");
            }
            else {
                itag.classList.add("using");
                itag.classList.remove("normal");
            }
        }, false);

        //取得前端傳來的參數
        // let isCaller = decodeURIComponent(getUrlParameter("isCaller"));
        // console.log(`isCaller:${isCaller}`);
        let paramObj = JSON.parse(decodeURIComponent(self.getUrlParameter("param")));
        document.getElementById("avatar").style.backgroundImage = "url(" + paramObj.imageurl + ")";
        document.getElementById("avatar2").style.backgroundImage = "url(" + paramObj.imageurl + ")";
        document.getElementById("span_title").innerText = paramObj.chatRoomTitle;
        document.getElementById("li_chatRoomTitle").innerText = `通話對象:${paramObj.chatRoomTitle}` + "\n" + `通話時間:${$VM2.$children[0].eTeam.rtcService.getDuration()}`;
        if (paramObj.state == "calling") {
            document.getElementById("divcancel").style.display = "block";
            document.getElementById("divwaiting").style.display = "none";

        }
        if (paramObj.state == "waiting") {
            document.getElementById("divhangup").style.display = "none";
            document.getElementById("divwaiting").style.display = "block";
        }
        if (paramObj.state == "talking") {
            document.getElementById("divhangup").style.display = "block";
            document.getElementById("divwaiting").style.display = "none";
            document.getElementById("video_container").style.display = "block";
            document.getElementById("divphone").style.display = "none";
            document.getElementById("dockmenu").style.display = "block";
            self.doOpenStream();
        }

        setInterval(() => {
            setTimeout(function () {
                document.getElementById("light1").classList.remove("graylight");
                document.getElementById("light1").classList.add("greenlight");
                document.getElementById("light2").classList.remove("greenlight");
                document.getElementById("light2").classList.add("graylight");
                document.getElementById("light3").classList.remove("greenlight");
                document.getElementById("light3").classList.add("graylight");
            }, 500);
            setTimeout(function () {
                document.getElementById("light1").classList.remove("greenlight");
                document.getElementById("light1").classList.add("graylight");
                document.getElementById("light2").classList.remove("graylight");
                document.getElementById("light2").classList.add("greenlight");
                document.getElementById("light3").classList.remove("greenlight");
                document.getElementById("light3").classList.add("graylight");
            }, 1000);
            setTimeout(function () {
                document.getElementById("light1").classList.remove("greenlight");
                document.getElementById("light1").classList.add("graylight");
                document.getElementById("light2").classList.remove("greenlight");
                document.getElementById("light2").classList.add("graylight");
                document.getElementById("light3").classList.remove("graylight");
                document.getElementById("light3").classList.add("greenlight");
            }, 1500);

        }, 1500);

        //每秒偵測
        setInterval(() => {
            try {
                const self = this;
                if ($VM2.$children[0].eTeam.rtcService.durationStart) {
                    document.getElementById("li_chatRoomTitle").innerText = `通話對象:${paramObj.chatRoomTitle}` + "\n" + `通話時間:${$VM2.$children[0].eTeam.rtcService.getDuration()}`;
                }
                self.getDuring();
            } catch (err) { console.log(`每秒偵測發生錯誤:[err:${err}]`); }
        }, 1000);

        let CameraRemote = document.getElementById("CameraRemote");

        let height = document.body.clientHeight;
        let width = document.body.clientWidth;
        CameraRemote.style.top = "85px";
        CameraRemote.style.left = (screen.width - 600) / 2 + "px";
        let avatar2 = document.getElementById("avatar2");
        avatar2.style.top = "85px";
        avatar2.style.left = (screen.width - 250) / 2 + "px";

        let CameraLocal = document.getElementById("CameraLocal");
        CameraLocal.style.top = "5px";
        CameraLocal.style.left = (screen.width - 230) + "px";

        /*
        if (paramObj.mqttCommand && paramObj.mqttCommand =="CloseVideo")
        {
            //console.log("對方已關閉視訊！");
            //alert("對方已關閉視訊！");
            document.getElementById("CameraRemote").srcObject = null;
            CameraRemote.style.display = "none";
            avatar2.style.display = "block";
            
        }
        if (paramObj.mqttCommand && paramObj.mqttCommand == "OpenVideo") {
            //console.log("對方開啟視訊！");
            //alert("對方開啟視訊！");
            //document.getElementById("CameraRemote").srcObject = $VM2.$children[0].eTeam.rtcService.remoteStream_webcam;
            self.doOpenStream();
            CameraRemote.style.display = "block";
            avatar2.style.display = "none";

        }       
        if (paramObj.mqttCommand && paramObj.mqttCommand == "OpenShare") {
            //console.log("對方開啟桌面共享！");
            //alert("對方開啟桌面共享！");

            
            let VideoRemote = document.getElementById("VideoRemote")
            VideoRemote.style.display = "block";
            VideoRemote.style.top = "0px";
            VideoRemote.style.left = "0px";
            self.doOpenStream();
            //document.getElementById("CameraRemote").srcObject = $VM2.$children[0].eTeam.rtcService.remoteStream_webcam;
            //self.doOpenStream();

            let height = document.body.clientHeight;
            let width = document.body.clientWidth;
            
            let CameraRemote = document.getElementById("CameraRemote");
            CameraRemote.style.top = "5px";
            CameraRemote.style.left = (screen.width - 230) + "px";
            
            CameraRemote.style.zIndex = "99";
            CameraRemote.style.width = "200px";
            //CameraRemote.style.left = "10px";

            let CameraLocal = document.getElementById("CameraLocal");
            CameraLocal.style.width = "200px";
            CameraLocal.style.top = "200px";
            CameraLocal.style.left =  (screen.width - 230) + "px";
            CameraLocal.style.zIndex = "99";
            
            


        }
        if (paramObj.mqttCommand && paramObj.mqttCommand == "CloseShare") {
            let VideoRemote = document.getElementById("VideoRemote")
            VideoRemote.style.display = "none";
            let CameraRemote = document.getElementById("CameraRemote");
            CameraRemote.style.top = "0px";
            CameraRemote.style.left = "0px";
            
        }
        */
        self.bindVideoAudioMuteState();
    }
    //
    getDuring() {
        let duration = "00:00:00";
        let sec_num = moment(Date.now()).diff(moment(durationStart), 'seconds');
        //var sec_num = parseInt(this, 10); // don't forget the second param
        var hours = Math.floor(sec_num / 3600);
        var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
        var seconds = sec_num - (hours * 3600) - (minutes * 60);

        if (hours < 10) { hours = "0" + hours; }
        if (minutes < 10) { minutes = "0" + minutes; }
        if (seconds < 10) { seconds = "0" + seconds; }
        duration = `${hours}:${minutes}:${seconds}`;
        document.getElementById("during").innerText = duration;
    }

    getUrlParameter(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
    };
    //播打者取消
    cancelByCaller() {
        const self = this;
        self.closeMyself("Cancel");
    }
    //播打者或接聽者掛斷
    hangupBySomeone() {
        const self = this;
        self.closeMyself("Hangup");
    }
    //接聽者拒接
    declineByCallee() {
        const self = this;
        self.closeMyself("Decline");
    }
    //接聽者未接
    noAnswerByCallee() {
        const self = this;
        self.closeMyself("NoAnswer");
    }
    //結束通話共用子函式
    closeMyself(eventType) {
        try {
            if (eventType) {
                $VM2.$children[0].eTeam.rtcService.mqtt(eventType);
            }
        } catch (err) { console.log(`[closeMyself]發mqtt發生錯誤:[err:${err}]`); }

        try {
            if (eventType) {
                $VM2.$children[0].eTeam.rtcService.sendFinishedCallMsg(eventType);
            }
        } catch (err) { console.log(`[closeMyself]呼叫API:產生message發生錯誤:[err:${err}]`); }

        try {
            $VM2.$children[0].eTeam.rtcService.closeVideoCall();
        } catch (err) { console.log(`[closeMyself]關閉連線發生錯誤:[err:${err}]`); }

        try {
            window.close();
        } catch (err) { console.log(`[closeMyself]關閉自己window.close()發生錯誤:[err:${err}]`); }
        try {
            $OPENWINDOW.close();
        } catch (err) { console.log(`[closeMyself]關閉自己$OPENWINDOW.close()發生錯誤:[err:${err}]`); }
        try {
            window.opener.postMessage("releaseOpenWindow", "*");
        } catch (err) { console.log(`[closeMyself]關閉自己window.opener.postMessage發生錯誤:[err:${err}]`); }
        try {
            $VM2.$children[0].eTeam.eTeam.isInDesktopRtc = false;
        } catch (err) { console.log(`[closeMyself]關閉自己VM2.$children[0].eTeam.eTeam.isInDesktopRtc = false發生錯誤:[err:${err}]`); }
    }
    //接聽者接聽
    doAccept() {
        try {
            if ($VM2.$children[0].eTeam.rtcService != null) {
                $VM2.$children[0].eTeam.rtcService.initWebRtc();
                $VM2.$children[0].eTeam.rtcService.setDuration(Date.now());
            }
            document.getElementById("divphone").style.display = "none";
            document.getElementById("dockmenu").style.display = "block";
            document.getElementById("divhangup").style.display = "block";
            document.getElementById("divwaiting").style.display = "none";
            document.getElementById("video_container").style.display = "block";
        } catch (err) { console.log(`[doAccept]按下接聽發生錯誤:[err:${err}]`); }
    }
    doOpenStream() {
        //顯示 Local Track
        setTimeout(() => {
            if ($VM2.$children[0].eTeam.rtcService.localStream != null) {
                if (document.getElementById("VideoLocal").srcObject == null) {
                    document.getElementById("VideoLocal").srcObject = $VM2.$children[0].eTeam.rtcService.localStream;
                    //document.getElementById("VideoLocal").play();
                    //alert(`rtcService.localStream is binding!`);
                    console.log(`rtcService.localStream is binding!`);
                }
            }
            else {
                //alert(`rtcService.localStream is still null!`);
                console.log(`rtcService.localStream is still null!`);
            }
        }, 2000);

        //顯示 Remote Track
        setTimeout(() => {
            if ($VM2.$children[0].eTeam.rtcService.remoteStream != null) {

                if (document.getElementById("VideoRemote").srcObject == null) {
                    document.getElementById("VideoRemote").srcObject = $VM2.$children[0].eTeam.rtcService.remoteStream;
                    //document.getElementById("VideoRemote").play();
                    //alert(`rtcService.remoteStream is binding!`);
                    console.log(`rtcService.remoteStream is binding!`);
                }
            }
            else {
                //alert(`rtcService.remoteStream is still null!`);
                console.log(`rtcService.remoteStream is still null!`);
            }
        }, 2000);
        //顯示 Local 視訊
        setInterval(() => {
            if ($VM2.$children[0].eTeam.rtcService.localStream_webcam != null) {
                if (document.getElementById("CameraLocal").srcObject == null) {
                    try {
                        document.getElementById("CameraLocal").srcObject = $VM2.$children[0].eTeam.rtcService.localStream_webcam;
                        //document.getElementById("CameraLocal").play();
                        //alert(`rtcService.localStream_webcam is binding!`);
                        console.log(`rtcService.localStream_webcam is binding!`);
                    }
                    catch (e)
                    { alert(e); }
                }
            }
            else {
                //alert(`rtcService.localStream_webcam is still null!`);
                console.log(`rtcService.localStream_webcam is still null!`);
            }
        }, 2000);

        //顯示 Remote 視訊
        setInterval(() => {
            if ($VM2.$children[0].eTeam.rtcService.remoteStream_webcam != null) {
                if (document.getElementById("CameraRemote").srcObject == null) {
                    try {
                        document.getElementById("CameraRemote").srcObject = $VM2.$children[0].eTeam.rtcService.remoteStream_webcam;
                        //document.getElementById("CameraRemote").play();
                        //alert(`rtcService.remoteStream_webcam is binding!`);
                        console.log(`rtcService.remoteStream_webcam is binding!`);
                    }
                    catch (e)
                    { alert(e); }
                }
            }
            else {
                //alert(`rtcService.remoteStream_webcam is still null!`);
                console.log(`rtcService.remoteStream_webcam is still null!`);
            }
        }, 2000);
    }

    bindVideoAudioMuteState() {
        try {
            //li_share
            if ($VM2.$children[0].eTeam.rtcService.localStream.getVideoTracks()[0].enabled == 0) {
                var itag = document.querySelector("#li_share").querySelector("i");
                itag.classList.remove("using");
                itag.classList.add("normal");
            }
            else {
                var itag = document.querySelector("#li_share").querySelector("i");
                itag.classList.add("using");
                itag.classList.remove("normal");
            }
            //li_video
            if ($VM2.$children[0].eTeam.rtcService.localStream_webcam.getVideoTracks()[0].enabled == 0) {
                var itag = document.querySelector("#li_video").querySelector("i");
                itag.classList.remove("using");
                itag.classList.add("normal");
            }
            else {
                var itag = document.querySelector("#li_video").querySelector("i");
                itag.classList.add("using");
                itag.classList.remove("normal");
            }
        }
        catch (ex) {

        }


    }



}


//drag anywhere http://jsfiddle.net/openube/3tx24p8f/
//function drag_start(event) {
//    var style = window.getComputedStyle(event.target, null);
//    event.dataTransfer.setData("text/plain",
//        (parseInt(style.getPropertyValue("left"), 10) - event.clientX) + ',' + (parseInt(style.getPropertyValue("top"), 10) - event.clientY));
//}
//function drag_over(event) {
//    event.preventDefault();
//    return false;
//}
//function drop(event) {
//    var offset = event.dataTransfer.getData("text/plain").split(',');
//    var dm = document.getElementById('dragme');
//    dm.style.left = (event.clientX + parseInt(offset[0], 10)) + 'px';
//    dm.style.top = (event.clientY + parseInt(offset[1], 10)) + 'px';
//    event.preventDefault();
//    return false;
//}


//var dm = document.getElementById('dragme');
//dm.addEventListener('dragstart', drag_start, false);
//document.body.addEventListener('dragover', drag_over, false);
//document.body.addEventListener('drop', drop, false);



////////////////////////
//var mousePos;

//document.onmousemove = handleMouseMove;
//setInterval(getMousePosition, 100); // setInterval repeats every X ms

//function handleMouseMove(event) {
//    var dot, eventDoc, doc, body, pageX, pageY;

//    event = event || window.event; // IE-ism

//    // If pageX/Y aren't available and clientX/Y are,
//    // calculate pageX/Y - logic taken from jQuery.
//    // (This is to support old IE)
//    if (event.pageX == null && event.clientX != null) {
//        eventDoc = (event.target && event.target.ownerDocument) || document;
//        doc = eventDoc.documentElement;
//        body = eventDoc.body;

//        event.pageX = event.clientX +
//            (doc && doc.scrollLeft || body && body.scrollLeft || 0) -
//            (doc && doc.clientLeft || body && body.clientLeft || 0);
//        event.pageY = event.clientY +
//            (doc && doc.scrollTop || body && body.scrollTop || 0) -
//            (doc && doc.clientTop || body && body.clientTop || 0);
//    }

//    mousePos = {
//        x: event.pageX,
//        y: event.pageY
//    };
//}
//function getMousePosition() {
//    var pos = mousePos;
//    if (!pos) {
//        // We haven't seen any movement yet
//    }
//    else {
//        // Use pos.x and pos.y
//        if (pos.y < 10) {
//            //var dockmenu = document.getElementById('dockmenu');
//            //dockmenu.classList.remove("hiddenHeight");
//            //dockmenu.classList.add("showHeight");
//            //setTimeout(function () {
//            //    dockmenu.style.height = "60px";
//            //    var ul_dockmenu = document.getElementById("ul_dockmenu");
//            //    ul_dockmenu.style.display = "";
//            //    //ul_dockmenu.classList.remove("hiddenHeight");
//            //    //ul_dockmenu.style.height = "48px";
//            //}, 600);

//            ////dockmenu.style.display = "";

//        }
//    }
//}