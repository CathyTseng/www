///Electron 專用 class，實作請放在class內
class PcService {
  constructor() {
    this.isPc = PcService.IsElectron && PcService.IsWin32;
    this.isOpenNotice = true;

    if (this.isPc) this._initPC();
  }

  static get IsElectron() {
    return window.navigator.userAgent.indexOf("electron") > 0;
  }
  static get IsWin32() {
    return window.navigator.platform.toLowerCase() == "win32";
  }
  static get PcVer() {
    let _arr = window.navigator.userAgent.split(" "); //PteamPC 0.x.0 electron
    if (_arr.length >= 2) return _arr[1];
    else return null;
  }

  get electron() {
    const electron = require("electron");
    return electron;
  }

  _initPC() {
    
    const self = this;
    window.alert = function(jsonstring) {
      /*func(jsonstring);*/
    };
    //const { ipcRender, remote, desktopCapturer } = require("electron");

    try {
      // self.electron.ipcRenderer.on("asynchronous-reply", (event, arg) => {
      //   self.isOpenNotice = arg.toLowerCase() == "closenotice" ? true : false;
      // });
      self.electron.ipcRenderer.on("desktop.app.quit", (event, arg) => {
        $VM.$children[0].eTeam.saveDataToLocal();
      });
    } catch (e) {
      console.log(e);
    }
  }

  async getDesktopSourceList() {
    //let a = await navigator.mediaDevices.getUserMedia({ audio: true, video: true })
    let sources = await this.electron.desktopCapturer.getSources({ types: ["window", "screen"] });

    return sources.map((v, i, arr) => v.name);
  }

  async getDesktopSource(sourceName) {
    //let a = await navigator.mediaDevices.getUserMedia({ audio: true, video: true })
    let sources = await this.electron.desktopCapturer.getSources({ types: ["window", "screen"] });

    for (const source of sources) {
      console.log(source);
      if (source.name === sourceName) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: {
              mandatory: {
                chromeMediaSource: "desktop",
                chromeMediaSourceId: source.id,
                minWidth: 1280,
                maxWidth: 1280,
                minHeight: 720,
                maxHeight: 720
              }
            }
          });
          console.log(stream);
          handleStream(stream);
        } catch (e) {
          handleError(e);
        }
        return;
      }
    }
  }

  async createNewWindow(url) {
    const { BrowserWindow } = this.electron.remote;
    console.log("show url", url);
    let _win = new BrowserWindow({ width: 800, height: 600 });
    _win.loadURL(url);
    _win.once('ready-to-show', () => {
      _win.show()
    });
  }

  sendToNative(eventName, data) {
    const self = this;
    if (self.isPc) {
      try {
        //overwrite
        
        if (window.require) {
          const mainwindow = this.electron.remote.getCurrentWindow();
          let _evName = eventName.toLowerCase();
          let obj = data;
          switch (_evName) {
            case "newmessage":
              
              // let param = {
              //   eventName: "newmessage",
              //   chatId: data.chatId
              // };

              const notifier = require("node-notifier");

              //mainwindow.restore();
              //mainwindow.show();
              if (self.isOpenNotice) {
                if (obj.totalUnRead) {
                  //[桌機]chatRoom設定不推播則右下角不提示
                  if (obj.pushType == "default") {
                    notifier.notify({
                      title: "Pteam通知",
                      message: "您有" + obj.totalUnRead + "則新訊息！",
                      icon: "eteam.ico",
                      sound: false,
                      url: "",
                      wait: true
                    });
                    notifier.on("click", function(notifierObject, options) {
                      //func(param);
                      //mainwindow.restore();
                      mainwindow.show();
                    });
                  }
                  self.electron.ipcRenderer.send("newmessage");
                } else {
                  // var notice_title =obj.timeStamp2+' '+ obj.name;
                  // var notice_message = obj.text;
                  // if (obj.sticker != null) {
                  //   notice_title = notice_title;
                  //   notice_message = '已傳送貼圖！';
                  // } else if (obj.imageId!=null)
                  // {
                  //   notice_message = "向您傳送圖片";
                  // }
                  // else {
                  //   notice_title = notice_title + '說:';
                  //   notice_message = obj.text;
                  // }
                }
              }
              break;
            case "openurl":
              window.open(data);
              break;
            case "appupdatepc":
              console.log(JSON.stringify(obj));

              $VM.$children[0].$f7.dialog.confirm(
                "桌機已有更新(" +
                  obj.eTeamPCAppVersion +
                  "),如您要立即更新,請按OK!(或請退出Pteam至MIS自助工具重新安裝)",
                "通知",
                //appupdatepcFunc,
                self.electron.ipcRenderer.send("appupdatepc"),
                ""
              );
              break;
            case "appupdateresource":
              console.log(JSON.stringify(obj));

              $VM.$children[0].$f7.dialog.confirm(
                "資源包已有更新(" +
                  obj.eTeamResourceAppVersion +
                  "),如您要立即更新,請按OK!",
                "通知",
                //appupdateresourceFunc,
                () => {
                  try {
                    self.electron.ipcRenderer.send("appupdateresource");
                    window.location.reload(true);
                  } catch (e) {
                    console.log(e);
                  }
                },
                ""
              );
              break;
            default:
              break;
          }

          // if (eventName.toLowerCase() == "newmessage".toLowerCase()) {

          // } else if (eventName.toLowerCase() == "openurl".toLowerCase()) {
          //   //mainwindow.setClosable(true);
          //   var obj = data;
          //   window.open(obj);
          // } else if (eventName.toLowerCase() == "appupdatepc".toLowerCase()) {
          //   var obj = data;
          //   console.log(JSON.stringify(obj));

          //   $VM.$children[0].$f7.dialog.confirm(
          //     "桌機已有更新(" +
          //       obj.eTeamPCAppVersion +
          //       "),如您要立即更新,請按OK!(或請退出Pteam至MIS自助工具重新安裝)",
          //     "通知",
          //     appupdatepcFunc,
          //     ""
          //   );
          // } else if (eventName.toLowerCase() == "appupdateresource".toLowerCase()) {
          //   var obj = data;
          //   console.log(JSON.stringify(obj));

          //   $VM.$children[0].$f7.dialog.confirm(
          //     "資源包已有更新(" +
          //       obj.eTeamResourceAppVersion +
          //       "),如您要立即更新,請按OK!",
          //     "通知",
          //     appupdateresourceFunc,
          //     ""
          //   );
          // }
        }
      } catch (e) {
        console.log(e);
      }
    }
  }

  // appupdatepcFunc() {
  //   try {
  //     const ipcRender = require("electron").ipcRenderer;
  //     ipcRender.send("appupdatepc");
  //   } catch (e) {
  //     console.log(e);
  //   }
  // }
  // appupdateresourceFunc() {
  //   try {
  //     const ipcRender = require("electron").ipcRenderer;
  //     ipcRender.send("appupdateresource");
  //     window.location.reload(true);
  //   } catch (e) {
  //     console.log(e);
  //   }
  // }

  showMessage(from, content, url, func) {
    const notifier = require("node-notifier");
    const remote = require("electron").remote;
    const window = remote.getCurrentWindow();
    window.restore();
    window.show();
    notifier.notify({
      title: from,
      message: content,
      icon: "eteam.ico",
      sound: false,
      url: "",
      wait: true
    });
    notifier.on("click", function(notifierObject, options) {
      // Triggers if `wait: true` and user clicks notification

      //if(options.url!=null && options.url!="")
      if (url != "") {
        //func.navigate(url, {reloadCurrent: true});
        if (func) {
          func(url);
          window.show();
        }
        // return url;
        // var webview = document.getElementById('mywebview')
        // console.log(options.url)
        // mywebview.loadURL(options.url);
        //location.href=options.url;
      }
      // alert('ok')
    });
  }
}
