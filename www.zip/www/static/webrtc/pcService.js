///Electron 專用 class，實作請放在class內
class PcService {
  constructor() {
    this.isPc = PcService.IsElectron && PcService.IsWin32;
    this.isOpenNotice = true;
    this.doucmentVisiblityState="norm"
    if (this.isPc) this._initPC();
  }

  static get IsElectron() {
    return window.navigator.userAgent.indexOf("electron") > 0;
  }
  
  static get IsWin32() {
    return (window.navigator.platform.toLowerCase() == "win32")||
    (window.navigator.platform.toLowerCase() == "macintel");
  }

  static get PcVer() {
    let _arr = window.navigator.userAgent.split(" "); //PteamPC 0.x.0 electron
    if (_arr.length >= 2) return _arr[1];
    else return null;
  }

  get electron() {
    const electron = require("electron");
    return electron;
  }

  get os(){
    const os = require("os");
    return os;
  }

  _initPC() {
    
    const self = this;
    window.alert = function(jsonstring) {
      /*func(jsonstring);*/
    };
    //const { ipcRender, remote, desktopCapturer } = require("electron");

    try {
      // self.electron.ipcRenderer.on("asynchronous-reply", (event, arg) => {
      //   self.isOpenNotice = arg.toLowerCase() == "closenotice" ? true : false;
      // });
      self.electron.ipcRenderer.on("desktop.app.quit", (event, arg) => {
        $VM.$children[0].eTeam.saveDataToLocal();
      });
      self.electron.ipcRenderer.on("asynchronous-reply", (event, arg) => {
        self.isOpenNotice = arg.toLowerCase() == "closenotice" ? true : false;
      });
      self.electron.ipcRenderer.on("mini",(eent,arg)=>{
        self.doucmentVisiblityState="mini";
      })
      self.electron.ipcRenderer.on("tray",(eent,arg)=>{
        self.doucmentVisiblityState="tray";
      });
      self.electron.ipcRenderer.on("fout",(eent,arg)=>{
        self.doucmentVisiblityState="fout";
      });
      self.electron.ipcRenderer.on("norm",(eent,arg)=>{
        self.doucmentVisiblityState="norm";
        $VM.$children[0].eTeam.sendReaded();
      })      
    } catch (e) {
      console.log(e);
    }
  }

  async getDesktopSourceList() {
    //let a = await navigator.mediaDevices.getUserMedia({ audio: true, video: true })
    let sources = await this.electron.desktopCapturer.getSources({ types: ["window", "screen"] });

    return sources.map((v, i, arr) => v.name);
  }

  async getDesktopSource(sourceName) {
    //let a = await navigator.mediaDevices.getUserMedia({ audio: true, video: true })
    let sources = await this.electron.desktopCapturer.getSources({ types: ["window", "screen"] });

    for (const source of sources) {
      //console.log(source);
      if (source.name === sourceName) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: {
              mandatory: {
                chromeMediaSource: "desktop",
                chromeMediaSourceId: source.id,
                minWidth: 1280,
                maxWidth: 1280,
                minHeight: 720,
                maxHeight: 720
              }
            }
          });
          //console.log(stream);
          // handleStream(stream);
          return stream;
        } catch (e) {
          handleError(e);
        }
        return;
      }
    }
  }

  async createNewWindow(url) {
    const { BrowserWindow } = this.electron.remote;
    console.log("show url", url);
    let _win = new BrowserWindow({ width: 800, height: 600 });
    _win.loadURL(url);
    _win.once('ready-to-show', () => {
      _win.show()
    });
  }

  sendToNative(eventName, data) {
    const self = this;
    if (self.isPc) {
      try {
        //overwrite
        
        if (window.require) {
          const mainwindow = this.electron.remote.getCurrentWindow();
          let _evName = eventName.toLowerCase();
          let obj = data;
          switch (_evName) {
            case "redspot":
              //console.log("obj.totalUnRead="+obj.totalUnRead)
              //add by vic send to 桌機顯示小紅點及隱藏小紅點用 2019/08/23
                if (obj.totalUnRead) {
                  if(parseInt(obj.totalUnRead)!=0)
                    self.electron.ipcRenderer.send("redspot");
                  else 
                    self.electron.ipcRenderer.send("nonspot");
                }
                else
                {
                  self.electron.ipcRenderer.send("nonspot");
                }
              break;
            case "newmessage":
              
              // let param = {
              //   eventName: "newmessage",
              //   chatId: data.chatId
              // };

              const notifier = require("node-notifier");

              //mainwindow.restore();
              //mainwindow.show();
              if (self.isOpenNotice) {
                if (obj.totalUnRead) {
                  //[桌機]chatRoom設定不推播則右下角不提示
                  if (obj.pushType == "default") {
                    notifier.notify({
                      title: "Pteam通知",
                      message: "您有" + obj.totalUnRead + "則新訊息！",
                      icon: "eteam.ico",
                      sound: false,
                      url: "",
                      wait: true
                    });
                    notifier.on("click", function(notifierObject, options) {
                      //func(param);
                      //mainwindow.restore();
                      mainwindow.show();
                    });
                  }
                  self.electron.ipcRenderer.send("newmessage");
                } else {
                  // var notice_title =obj.timeStamp2+' '+ obj.name;
                  // var notice_message = obj.text;
                  // if (obj.sticker != null) {
                  //   notice_title = notice_title;
                  //   notice_message = '已傳送貼圖！';
                  // } else if (obj.imageId!=null)
                  // {
                  //   notice_message = "向您傳送圖片";
                  // }
                  // else {
                  //   notice_title = notice_title + '說:';
                  //   notice_message = obj.text;
                  // }
                }
              }
              break;
            case "openurl":
              window.open(data);
              break;
            case "appupdatepc":
              console.log(JSON.stringify(obj));
              if(obj.systemType == "pc")
              {
                $VM.$children[0].$f7.dialog.confirm(
                  "桌機已有更新版本(" +
                    obj.eTeamPCAppVersion +
                    "),如您要立即更新,請按OK!(或關閉Pteam,至MIS自助工具重新安裝!)",
                  "通知",
                  () => {
                    try {
                      self.electron.ipcRenderer.send("appupdatepc");
                    } catch (e) {
                      console.log(e);
                    }
                  },
                  ""
                );
              }
              else
              {
                $VM.$children[0].$f7.dialog.alert(
                  "桌機已有更新版本(" +
                    obj.eTeamPCAppVersion +
                    "),如您要更新,請關閉Pteam後,至MIS自助工具重新安裝!",
                  "通知",
                  ""
                );
              }
              break;
            case "appupdateresource":
              try {
                self.electron.ipcRenderer.send("appupdateresource");
              } catch (error) {
                console.log(e);
              }

              //console.log(JSON.stringify(obj));

              // $VM.$children[0].$f7.dialog.confirm(
              //   "資源包已有更新版本(" +
              //     obj.eTeamResourceAppVersion +
              //     "),如您要立即更新,請按OK!",
              //   "通知",
              //   () => {
              //     try {
              //       self.electron.ipcRenderer.send("appupdateresource");
              //     } catch (e) {
              //       console.log(e);
              //     }
              //   },
              //   ""
              // );
              break;
            default:
              break;
          }
        }
      } catch (e) {
        console.log(e);
      }
    }
  }

  showMessage(from, content, url, func) {
    const notifier = require("node-notifier");
    const remote = require("electron").remote;
    const window = remote.getCurrentWindow();
    window.restore();
    window.show();
    notifier.notify({
      title: from,
      message: content,
      icon: "eteam.ico",
      sound: false,
      url: "",
      wait: true
    });
    notifier.on("click", function(notifierObject, options) {
      // Triggers if `wait: true` and user clicks notification

      //if(options.url!=null && options.url!="")
      if (url != "") {
        //func.navigate(url, {reloadCurrent: true});
        if (func) {
          func(url);
          window.show();
        }
        // return url;
        // var webview = document.getElementById('mywebview')
        // console.log(options.url)
        // mywebview.loadURL(options.url);
        //location.href=options.url;
      }
      // alert('ok')
    });
  }
}
